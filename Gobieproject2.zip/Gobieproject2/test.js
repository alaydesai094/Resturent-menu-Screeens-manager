var db = firebase.firestore();


var fileButton;
var file;
var img;


var userID = "";
var itemName = "";
var screen1 = "";
var screen2 = "";
var screen3 = "";

var outResult = [];

var outImages = [];

var count;

var indexPage = document.body.id;

var dname = document.getElementById("dname");
var dID = document.getElementById("dID");

var before1 = document.getElementById('before1');
var before2 = document.getElementById('before2');
var before3 = document.getElementById('before3');


// ----------------- List all the Stores here ------------------------------

if(indexPage == "index"){

function Showdata(){
// get All data from the firestore
//const listData = document.querySelector("#ListData");

db.collection("gobieStore").onSnapshot(function(querySnapshot) {
  querySnapshot.docChanges().forEach(function(change) {


    if (change.type === "added") {

     userID = change.doc.data().id;
     itemName = change.doc.data().name;
     screen1 = change.doc.data().screen1;
     screen2 = change.doc.data().screen2;
      screen3 = change.doc.data().screen3;

      count = count+1;


      createTable(count);
   }

    });
});

}
// end

function  createTable(count) {

// get the html table
// 0 = the first table
var table = document.getElementsByTagName('table')[0];

// add new empty row to the table
// 0 = in the top
// table.rows.length = the end
// table.rows.length/2+1 = the center
var newRow = table.insertRow(table.rows.length/2+1);

// add cells to the row
cel1 = newRow.insertCell(0);
var cel2 = newRow.insertCell(1);
var cel3 = newRow.insertCell(2);
var cel4 = newRow.insertCell(3)
var cel5 = newRow.insertCell(4)

outResult.push(count);

for (let i = 0; i < outResult.length; i++) {

  // add values to the cells
cel1.innerHTML =  "<button id ="+outResult[i]+" class='styleBoxButton' value ="+userID+" onclick='openForm()'>"+userID+"</button>";
//console.log(cel1.id);

}

cel2.innerHTML = itemName;
cel3.innerHTML = screen1;
cel4.innerHTML = screen2;
cel5.innerHTML = screen3;
// outResult.push(userID,itemName,itemNote);


} // ends

Showdata();

function openForm(){

  //window.open("UploadScreens.html");
  location.href='UploadScreens.html'
  var passID = event.srcElement.value;
  localStorage.setItem("passedID",passID);

}


}// index page ends


// ----------------- Upload Scree starts here ------------------------------


if(indexPage == "UploadScreens"){
  console.log(indexPage);

var passedID = localStorage.getItem("passedID");
console.log(passedID.toString());

showNextpageData(passedID);

  //Screen 1
  fileButton1.addEventListener('change',function(e){

  file = e.target.files[0];

  var storageRef = firebase.storage().ref('images/'+file.name);
  storageRef.put(file);
    var img = document.getElementById('myimg1');
    var imgUrl = document.getElementById('Url1');
    showImage(img,imgUrl);

    db.collection("gobieStore").doc(passedID).update({
      screen1: file.name
    })
    .then(function() {
      console.log("Document successfully updated!");
    })
    .catch(function(error) {
      // The document probably doesn't exist.
      console.error("Error updating document: ", error);
    });

  });


//Screen 2
fileButton2.addEventListener('change',function(e){

file = e.target.files[0];

var storageRef = firebase.storage().ref('images/'+file.name);
storageRef.put(file);
  var img = document.getElementById('myimg2');
  var imgUrl = document.getElementById('Url2');
  showImage(img,imgUrl);

  db.collection("gobieStore").doc(passedID).update({
    screen2: file.name
  })
  .then(function() {
    console.log("Document successfully updated!");
  })
  .catch(function(error) {
    // The document probably doesn't exist.
    console.error("Error updating document: ", error);
  });

});



  //Screen 3
  fileButton3.addEventListener('change',function(e){

  file = e.target.files[0];

  var storageRef = firebase.storage().ref('images/'+file.name);
  storageRef.put(file);
    var img = document.getElementById('myimg3');
    var imgUrl = document.getElementById('Url3');
    showImage(img,imgUrl);

    db.collection("gobieStore").doc(passedID).update({
      screen3: file.name
    })
    .then(function() {
      console.log("Document successfully updated!");
    })
    .catch(function(error) {
      // The document probably doesn't exist.
      console.error("Error updating document: ", error);
    });

  });



function showImage(img,imgUrl){

  var storageRef = firebase.storage().ref('images/'+file.name);

storageRef.getDownloadURL().then(function(url) {
  // `url` is the download URL for 'images/stars.jpg'

  // This can be downloaded directly:
  var xhr = new XMLHttpRequest();
  xhr.responseType = 'blob';
  xhr.onload = function(event) {
    var blob = xhr.response;
  };
  xhr.open('GET', url);
  xhr.send();

  // Or inserted into an <img> element:

  img.src = url;
  imgUrl.innerHTML = "<a href="+ url +">Show Image </a>";

   // img2.src = url;
   //
   //  img3.src = url;
}).catch(function(error) {
  // Handle any errors
});

}


function showNextpageData(passedID){

db.collection("gobieStore").doc(passedID)
.get().then(function(doc) {
  if (doc.exists){
    // Convert to City object
  var rid = doc.data().id;
  var rname = doc.data().name;
  var rscreen1 = doc.data().screen1;
  var rscreen2 = doc.data().screen2;
  var rscreen3 = doc.data().screen3;

     dID.innerHTML = rid;
     dname.innerHTML = rname;


      outImages.push(rscreen1,rscreen2,rscreen3);
      console.log(outImages);

      for (let c = 0; c < outImages.length; c++) {

        imageData = outImages[c];
        ShowBeforeImage(imageData);
        console.log("passing data" +imageData);
      }


    //ShowBeforeImage();


    // Use a City instance method
    //console.log(dID+","+dname);
  } else {
    console.log("No such document!")
  }}).catch(function(error) {
    console.log("Error getting document:", error)
  });

}





function ShowBeforeImage(imageData){
// loading images from the firebase database
  console.log("Going to downloads perviously uploaded");

  // Create a storage reference from our storage service
var storageRef = firebase.storage().ref();

//for (let c = 0; c < outResult.length; c++) {

var listRef = storageRef.child('images/'+imageData);

listRef.getDownloadURL().then(function(url) {
  // `url` is the download URL for 'images/stars.jpg'

  // This can be downloaded directly:
  var xhr = new XMLHttpRequest();
  xhr.responseType = 'blob';
  xhr.onload = function(event) {
    var blob = xhr.response;
  };
  xhr.open('GET', url);
  xhr.send();

  // Or inserted into an <img> element:

  for (let d = 0; d < outImages.length; d++) {

if(imageData == outImages[0]){
  before1.src = url;
  //console.log(imageData, outImages[]);
}
if(imageData == outImages[1]){
  before2.src = url;
}
if(imageData == outImages[2]){
  before3.src = url;
}

}

  //imgUrl.innerHTML = "<a href="+ url +">Show Image </a>";
}).catch(function(error) {
  // Handle any errors
});
}//end


}// UploadScreens ends
